import { useState, useEffect } from "react";
import { Container, Typography, Grid, Card, CardActionArea, CardContent } from "@mui/material";
import { useNavigate } from "react-router-dom";

const API_URL = "http://localhost:8080/strelive-api/api/stream";

const Home = () => {
  const [videos, setVideos] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetch(API_URL)
      .then((response) => response.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setVideos(data);
        } else {
          console.error("Invalid API response:", data);
        }
      })
      .catch((error) => console.error("Error fetching videos:", error))
      .finally(() => setLoading(false));
  }, []);

  return (
    <Container>
      <Typography variant="h3" gutterBottom>
        Livestreams
      </Typography>
      {loading ? (
        <Typography>Loading...</Typography>
      ) : videos.length === 0 ? (
        <Typography>No streams available.</Typography>
      ) : (
        <Grid container spacing={2}>
          {videos.map((videoUrl, index) => {
            const key = videoUrl.split("/").pop()?.replace(".m3u8", ""); // Extract stream key
            return (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <Card>
                  <CardActionArea onClick={() => navigate(`/watch/${key}`)}>
                    <CardContent>
                      <Typography variant="h6">{key}</Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      )}
    </Container>
  );
};

export default Home;
